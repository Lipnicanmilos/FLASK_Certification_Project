peoples = [{'name': 'Peter', 'birth-year': 1987},
          {'name': 'Milos', 'birth-year': 1990}]

messages = [{'title': 'Message One',
             'content': 'Message One Content'},
            {'title': 'Message Two',
             'content': 'Message Two Content'}
            ]