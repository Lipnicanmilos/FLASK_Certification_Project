# activate environment
-- venv/Scripts/activate
# run flask app
-- python alta3research-flask01.py
-- python alta3research-flask02.py

{
pip list:
    Package            Version
------------------ -------
click              8.1.2  
colorama           0.4.4  
Flask              2.1.1  
importlib-metadata 4.11.3 
itsdangerous       2.1.2  
Jinja2             3.1.1  
MarkupSafe         2.1.1  
pip                22.0.4 
setuptools         56.0.0 
Werkzeug           2.1.1  
zipp               3.8.0 
}